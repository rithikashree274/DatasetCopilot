import os, re, subprocess, shutil, textwrap

BLACKLIST = [
    r"import\s+os", r"import\s+subprocess", r"os\.system",
    r"subprocess\.", r"eval\(", r"exec\(", r"open\("
]
TIMEOUT = 10


def _flag(code: str):
    low = code.lower()
    for pat in BLACKLIST:
        if re.search(pat, low):
            return pat
    return None


def run_code_in_sandbox(code: str, work_dir: str):
    """
    Executes `code` safely in `work_dir`.
    Prepends:
       * matplotlib 'Agg' backend + autosave show()
       * creation of `dflc` (lowercase columns)
    """
    os.makedirs(work_dir, exist_ok=True)

    bad = _flag(code)
    if bad:
        return {"success": False, "output": f"🚫 Disallowed pattern: {bad}"}
    
    _saved = []  # to collect saved plot filenames
    preamble = textwrap.dedent("""
        import os, matplotlib, pandas as pd
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        # autosave every plt.show()
        import uuid, pathlib

        _saved = []
        def _auto():
            fn = f"plot_{uuid.uuid4().hex[:8]}.png"
            plt.gcf().savefig(fn)
            _saved.append(fn)          # record for outer process
        plt.show = _auto


        # create dflc for case-insensitive access if df exists later
        try:
            if 'df' in globals():
                dflc = df.copy(); dflc.columns = dflc.columns.str.lower()
        except Exception:
            pass
    """).lstrip()

    tmp = "temp_code.py"
    with open(os.path.join(work_dir, tmp), "w", encoding="utf-8") as fh:
        fh.write(preamble + "\n" + code)

    # mirror files into a 'data' subfolder for codes that use that prefix
    data_sub = os.path.join(work_dir, "data")
    os.makedirs(data_sub, exist_ok=True)
    for f in os.listdir(work_dir):
        src = os.path.join(work_dir, f)
        dst = os.path.join(data_sub, f)
        if os.path.isfile(src) and f != tmp and not os.path.exists(dst):
            try:
                os.link(src, dst)
            except OSError:
                shutil.copy2(src, dst)

    try:
        res = subprocess.run(
            ["python", tmp], cwd=work_dir,
            capture_output=True, text=True, timeout=TIMEOUT
        )
    except subprocess.TimeoutExpired:
        return {"success": False, "output": f"⏰ Timeout > {TIMEOUT}s"}
    finally:
        try: os.remove(os.path.join(work_dir, tmp))
        except OSError: pass

    out = (res.stdout or "") + (res.stderr or "")
    return {
        "success": res.returncode == 0,
        "output": out,
        "plots": _saved              # ← new key
    }


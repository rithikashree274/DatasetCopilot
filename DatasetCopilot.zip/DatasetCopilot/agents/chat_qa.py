from __future__ import annotations
import os, json, textwrap, pandas as pd, re

from .base import BaseAgent
from core import sandbox_utils


class ChatQAAgent(BaseAgent):
    """
    - Supplies exact column list to Gemini.
    - Offers helper dataframe `dflc` (all-lowercase columns) for
      case-insensitive access.
    - Executes returned code; on KeyError auto-retries with lowercase map.
    """

    def __init__(self):
        super().__init__(name="chat_qa")

    def run(
        self,
        question: str,
        dataset_summary: str | None = None,
        last_result: str | None = None,
        df: pd.DataFrame | None = None,
    ):
        ctx_parts: list[str] = []
        if dataset_summary:
            ctx_parts.append(f"**Dataset summary**\n{dataset_summary}")

        if df is not None:
            schema = ", ".join(df.columns)
            ctx_parts.append(f"**Columns (case-sensitive)**  \n{schema}")
            ctx_parts.append("**Tip:** `dflc` is the same dataframe but with "
                             "all-lowercase column names for convenience.")
            ctx_parts.append(f"**Head**\n{df.head().to_markdown(index=False)}")

        if last_result:
            ctx_parts.append(f"**Last output**\n{last_result[-1000:]}")

        context_block = "\n\n".join(ctx_parts)

        user_prompt = textwrap.dedent(f"""
            {context_block}

            **User question:** {question}

            Respond **only** with JSON in <final_json> tags:

            <final_json>
            {{
              "answer": "natural language response",
              "code": "df['Revenue'].mean()"   # optional; must be ONE LINE
            }}
            </final_json>

            • Include "code" ONLY if it directly computes the answer.  
            • You may use either `df` (original columns) or `dflc`
              (all-lowercase column names).  
            • Columns are case-sensitive in `df`.
        """)

        reply: dict = self._call(user_prompt, temperature=0.35, max_tokens=512)

        # ------------ execute code if provided ------------
        def execute(code_line: str):
            work_dir = "app/assets/data"
            os.makedirs(work_dir, exist_ok=True)
            snap = os.path.join(work_dir, "_df_snapshot.pkl")
            df.to_pickle(snap)

            snippet = (
                "import pandas as pd, json, re\n"
                f"df = pd.read_pickle('{os.path.basename(snap)}')\n"
                "dflc = df.copy(); dflc.columns = dflc.columns.str.lower()\n"
                f"val = {code_line}\n"
                "if isinstance(val, (pd.Series, pd.DataFrame)):\n"
                "    val = val.to_dict()\n"
                "print(json.dumps({'calc': val}, default=str))"
            )
            return sandbox_utils.run_code_in_sandbox(snippet, work_dir)

        if isinstance(reply, dict) and df is not None:
            code_line = str(reply.get("code", "")).strip()
            if code_line:
                res = execute(code_line)

                # If KeyError due to case mismatch, retry with lowercase fix
                if (not res["success"]
                        and re.search(r"KeyError:.*", res["output"])
                        and "[" in code_line):        # simple heuristic
                    lower_line = code_line.replace("df[", "dflc[")
                    res = execute(lower_line)

                if res["success"]:
                    calc_val = json.loads(res["output"]).get("calc")

                    if isinstance(calc_val, dict):
                        reply["answer"] += f"\n\n```json\n{json.dumps(calc_val, indent=2)}\n```"
                    elif calc_val is not None:
                        reply["answer"] += f" → **{calc_val}**"
                    # else: just keep the plain-language answer

                else:
                    reply["answer"] += f"\n\n(Execution failed)\n{res['output']}"

        return reply

import os
import pandas as pd
import zipfile
import tempfile

def ensure_dir(path: str):
    """Ensure the directory exists. Create it if it doesn't."""
    os.makedirs(path, exist_ok=True)

def clear_dir(path: str):
    """Remove all contents of the directory if it exists."""
    if os.path.isdir(path):
        for filename in os.listdir(path):
            file_path = os.path.join(path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.remove(file_path)
                elif os.path.isdir(file_path):
                    import shutil
                    shutil.rmtree(file_path)
            except Exception as e:
                # If deletion fails, ignore for now
                pass

def save_uploaded_file(uploaded_file, save_dir="app/assets/data"):
    """
    Save a Streamlit uploaded file to disk. Returns the saved file path.
    """
    ensure_dir(save_dir)
    # We will save with the same filename as uploaded (use only base name for safety).
    filename = os.path.basename(uploaded_file.name)
    save_path = os.path.join(save_dir, filename)
    # Save file data to disk
    with open(save_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return save_path

def extract_zip_file(zip_path: str, extract_dir="app/assets/data"):
    """
    Extract a zip file to the given directory. Returns a list of extracted file paths.
    """
    ensure_dir(extract_dir)
    # Clear out the directory first to avoid mixing old files
    clear_dir(extract_dir)
    extracted_files = []
    with zipfile.ZipFile(zip_path, 'r') as zipf:
        for member in zipf.namelist():
            # Only extract files (skip directories)
            if member.endswith('/'):
                continue
            # We won't extract files with potentially dangerous paths
            filename = os.path.basename(member)
            if not filename:
                continue
            dest_path = os.path.join(extract_dir, filename)
            with open(dest_path, 'wb') as outfile:
                outfile.write(zipf.read(member))
            extracted_files.append(dest_path)
    return extracted_files

def load_dataset(file_path: str):
    """
    Load dataset from the given file path (CSV, Excel, or similar).
    Returns a pandas DataFrame or a dict of DataFrames if multiple files (for zip archives).
    """
    # Determine file extension
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".csv":
        df = pd.read_csv(file_path)
        return df
    elif ext in [".xls", ".xlsx"]:
        # read all sheets as dict of DataFrame? Or just first sheet?
        try:
            df = pd.read_excel(file_path)
        except ImportError as e:
            # If openpyxl not installed for .xlsx, raise a clear error
            raise e
        return df
    else:
        # If file type is not supported directly, raise error
        raise ValueError(f"Unsupported file format: {ext}")

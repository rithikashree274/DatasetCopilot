import os, toml

CONFIG = {}
CFG_DIR = os.path.dirname(__file__)
settings = os.path.join(CFG_DIR, "settings.toml")
example  = os.path.join(CFG_DIR, "settings.toml.example")

if os.path.exists(settings):
    CONFIG = toml.load(settings)
elif os.path.exists(example):
    CONFIG = toml.load(example)
    print("⚠️  Using example settings file — create config/settings.toml with real keys.")
else:
    CONFIG = {}

# Environment fallback for quick tests
if "gemini" not in CONFIG:
    CONFIG["gemini"] = {
        "light_model": "models/gemini-1.5-pro-latest",
        "pro_model"  : "models/gemini-1.5-pro-latest",
        "light_api_key": os.getenv("GEMINI_API_KEY", ""),
        "pro_api_key"  : os.getenv("GEMINI_API_KEY", "")
    }

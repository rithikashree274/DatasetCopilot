**Example:**
User: What is (2 + 3) * 4?
Assistant:
<scratchpad>
Calculate 2+3 = 5. 
Then 5 * 4 = 20.
</scratchpad>
<final_json>
{"result": 20}
</final_json>

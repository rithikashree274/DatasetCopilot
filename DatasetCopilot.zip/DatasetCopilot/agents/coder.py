from .base import BaseAgent
import os, textwrap


class CoderAgent(BaseAgent):
    """Generate Python code for the chosen analysis idea."""

    def __init__(self):
        super().__init__(name="coder", use_pro=True)

    def run(self, idea: str, file_path: str, df_columns=None):
        fname = os.path.basename(file_path)
        cols  = ", ".join(df_columns) if df_columns else "<unknown>"

        user_prompt = textwrap.dedent(f"""
            You are an expert Python data-analyst.

            • Dataset file: **{fname}** is in the current working directory.
            • Available columns (case-sensitive): {cols}
              A helper dataframe `dflc` (all-lowercase column names) will
              also be provided at runtime for convenience.

            Task: **{idea}**

            Write COMPLETE Python code:
              ─ load the file with pandas
              ─ perform the analysis
              ─ print or plot results
            Use the exact column spelling from the list above,
            or use dflc['revenue'] style if you prefer lowercase.

            Return ONLY JSON:
            <final_json>
            {{
              "code": [
                "# imports …",
                "import pandas as pd",
                …
              ]
            }}
            </final_json>
        """)

        res = self._call(user_prompt, temperature=0.2, max_tokens=1500)
        return res

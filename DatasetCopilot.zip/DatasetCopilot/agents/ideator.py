from .base import BaseAgent

class IdeatorAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="ideator")
    def run(self, profile_info):
        """
        Generate analysis ideas/questions based on dataset profile info.
        profile_info: could be a dict from profiler or summary text.
        Returns a dict with list of ideas.
        """
        # Prepare profile data for prompt
        if isinstance(profile_info, str):
            profile_text = profile_info
        else:
            # If dict from profiler, maybe it contains a summary or other fields
            # Use summary text if available, otherwise just list columns and types
            if "summary" in profile_info:
                profile_text = profile_info["summary"]
            else:
                # Fallback: just show columns
                cols = profile_info.get("column_summaries", {}).keys() if isinstance(profile_info, dict) else []
                profile_text = f"Columns: {', '.join(cols)}"
        user_content = (f"The dataset profile information is:\n{profile_text}\n"
                        f"Please suggest 3 to 5 interesting analysis ideas or questions for this dataset. "
                        f"Provide them as a JSON object with an 'ideas' list.")
        result = self._call(user_content)
        return result

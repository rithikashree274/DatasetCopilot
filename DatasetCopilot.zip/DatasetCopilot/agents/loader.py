from .base import BaseAgent
from core import file_utils

class LoaderAgent(BaseAgent):
    def __init__(self):
        # No prompt needed for loader
        super().__init__(name="loader")
    def run(self, file_obj):
        """
        Load the dataset from the uploaded file object. Returns a dict with DataFrame and info.
        """
        # Save uploaded file to disk and load it
        # Clear any previous data directory
        data_dir = "app/assets/data"
        file_utils.ensure_dir(data_dir)
        file_utils.clear_dir(data_dir)
        file_path = file_utils.save_uploaded_file(file_obj, save_dir=data_dir)
        # If zip file, extract and determine primary dataset file
        if file_path.lower().endswith(".zip"):
            extracted_files = file_utils.extract_zip_file(file_path, extract_dir=data_dir)
            # Filter to supported formats
            data_files = [f for f in extracted_files if f.lower().endswith((".csv", ".xls", ".xlsx"))]
            if len(data_files) == 0:
                raise ValueError("No data file found in the ZIP archive.")
            # If multiple, choose the first for now
            data_files.sort()
            main_file = data_files[0]
            if len(data_files) > 1:
                # We will ignore additional files for now
                others = data_files[1:]
            else:
                others = []
            df = file_utils.load_dataset(main_file)
            return {"df": df, "file_path": main_file, "other_files": others}
        else:
            # Single file
            df = file_utils.load_dataset(file_path)
            return {"df": df, "file_path": file_path, "other_files": []}

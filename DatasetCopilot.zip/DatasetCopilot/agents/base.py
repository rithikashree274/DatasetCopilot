"""
Shared Gemini-powered base class for all LLM agents.

Highlights
──────────
* Loads YAML prompt templates (`prompts/<agent>.yaml`).
* Supports optional few-shot examples.
* Uses google-generativeai SDK (Gemini) for both stateless
  `generate_content()` and long-running chat sessions.
* Extracts JSON from a `<final_json>…</final_json>` contract and
  retries once if the JSON is invalid.
"""

from __future__ import annotations
import os, json, re, yaml
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Tuple

from google import genai
from google.genai import types as gtypes

from config import CONFIG

PROMPT_DIR = os.path.join(os.path.dirname(__file__), "..", "prompts")


def _load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _extract_json(contract_text: str) -> Dict[str, Any]:
    """
    Pull JSON out of <final_json>…</final_json> or the first {...} block.
    """
    if "<final_json>" in contract_text:
        m = re.search(r"<final_json>(.*?)</final_json>", contract_text, re.S)
        if m:
            return json.loads(m.group(1).strip())
    # Fallback: first balanced braces
    brace = re.search(r"\{.*\}", contract_text, re.S)
    if brace:
        return json.loads(brace.group(0))
    raise ValueError("No JSON block found")


class BaseAgent(ABC):
    """
    Every concrete agent subclasses this and implements `.run()`.
    """

    def __init__(self,
                 name: str,
                 use_pro: bool = False,
                 use_chat: bool = False):
        self.name = name.lower()
        self.use_pro = use_pro
        self.use_chat = use_chat

        # ---------- load prompt ----------
        yaml_path = os.path.join(PROMPT_DIR, f"{self.name}.yaml")
        self.prompt_cfg = _load_yaml(yaml_path) if os.path.exists(yaml_path) else {}
        self.system_prompt: str | None = self.prompt_cfg.get("system")
        self.examples: List[Tuple[str, str]] = [
            (ex["user"], ex["assistant"])
            for ex in self.prompt_cfg.get("examples", [])
            if isinstance(ex, dict) and "user" in ex and "assistant" in ex
        ]

        # ---------- model / key routing ----------
        gem_cfg = CONFIG.get("gemini", {})
        model_key = "pro_model" if self.use_pro else "light_model"
        api_key_key = "pro_api_key" if self.use_pro else "light_api_key"

        self.model_id = gem_cfg.get(model_key) or "models/gemini-1.5-pro-latest"
        self.api_key = gem_cfg.get(api_key_key) or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise RuntimeError("Gemini API key missing — set GEMINI_API_KEY or config/gemini section.")

        self.client = genai.Client(api_key=self.api_key)

        # Pre-create chat if requested
        self.chat = None
        if self.use_chat:
            cfg = gtypes.GenerateContentConfig()
            if self.system_prompt:
                cfg.system_instruction = self.system_prompt
            self.chat = self.client.chats.create(model=self.model_id, config=cfg)

    # ───────────────────────── helpers ──────────────────────────
    def _format_prompt(self, user_content: str) -> List[str]:
        """
        Build the prompt list: system → examples → user.
        """
        parts: List[str] = []
        if self.system_prompt:
            parts.append(self.system_prompt)
        for u, a in self.examples:
            parts.append(f"User: {u}")
            parts.append(f"Assistant: {a}")
        parts.append(user_content)
        return parts

    def _call(self, user_content: str, temperature: float = 0.2, max_tokens: int = 1024) -> Dict[str, Any]:
        """
        Send the prompt and parse JSON response with one retry on failure.
        """
        prompt_parts = self._format_prompt(user_content)

        def _send() -> str:
            if self.use_chat and self.chat:
                return self.chat.send_message(prompt_parts[-1]).text
            else:
                resp = self.client.models.generate_content(
                    model=self.model_id,
                    contents=prompt_parts,
                    # generation_config=gtypes.GenerationConfig(
                    #     temperature=temperature,
                    #     max_output_tokens=max_tokens
                    # )
                )
                return resp.text

        for attempt in range(2):
            raw = _send()
            try:
                return _extract_json(raw)
            except Exception as err:
                if attempt == 0:
                    # retry with stern instruction
                    user_content_retry = (
                        user_content
                        + "\n\nIMPORTANT: Return ONLY valid JSON in <final_json>...</final_json>."
                    )
                    prompt_parts[-1] = user_content_retry
                else:
                    raise RuntimeError(f"{self.name} JSON parse failed") from err

    # ───────────── to be implemented by subclasses ─────────────
    @abstractmethod
    def run(self, *args, **kwargs): ...

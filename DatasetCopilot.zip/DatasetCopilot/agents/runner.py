from .base import BaseAgent
from core import sandbox_utils

class RunnerAgent(BaseAgent):
    def __init__(self):
        # No prompt, not using LLM
        super().__init__(name="runner")
    def run(self, code_lines):
        """
        Execute the given code (list of lines or single string) in a sandboxed environment.
        Returns a dict with success status and output.
        """
        if isinstance(code_lines, list):
            code_str = "\n".join(code_lines)
        else:
            code_str = str(code_lines)
        result = sandbox_utils.run_code_in_sandbox(code_str, work_dir="app/assets/data")
        return result

import pandas as pd
import numpy as np

def profile_dataframe(df: pd.DataFrame, max_unique_for_cat: int = 15):
    """
    Create a profiling summary of a pandas DataFrame.
    Returns a dictionary with summary information.
    """
    profile = {}
    n_rows, n_cols = df.shape
    profile["rows"] = int(n_rows)
    profile["columns"] = int(n_cols)
    col_summaries = {}
    for col in df.columns:
        col_data = df[col]
        col_summary = {}
        # Basic info
        dtype = str(col_data.dtype)
        col_summary["dtype"] = dtype
        # Missing values
        missing_count = int(col_data.isna().sum())
        if missing_count > 0:
            col_summary["missing_count"] = missing_count
            col_summary["missing_ratio"] = round(missing_count / n_rows, 3)
        # Determine type category: numeric vs categorical
        is_numeric = pd.api.types.is_numeric_dtype(col_data)
        unique_count = int(col_data.nunique(dropna=True))
        col_summary["unique_count"] = unique_count
        # If numeric and many unique values, treat as numeric; if numeric but few unique, treat as categorical maybe
        if is_numeric:
            # If every value is unique and number of rows is large, likely an ID
            if unique_count == n_rows:
                col_summary["likely_id"] = True
            # Compute numeric stats if possible
            try:
                # Drop NaNs for stats
                nonna = col_data.dropna()
                if len(nonna) > 0:
                    col_summary["min"] = float(nonna.min())
                    col_summary["max"] = float(nonna.max())
                    # Only compute mean, std if more than one non-NaN value
                    if len(nonna) > 1:
                        col_summary["mean"] = float(nonna.mean())
                        col_summary["std"] = float(nonna.std())
            except Exception as e:
                # If numeric stats fail (for object numeric), skip
                pass
            # If numeric but unique_count is small relative to rows, note it could be categorical
            if unique_count <= max_unique_for_cat and unique_count < n_rows:
                col_summary["considered_categorical"] = True
                # List unique values (e.g., small number of categories)
                try:
                    unique_vals = list(map(lambda x: x if pd.notna(x) else None, col_data.unique()))
                    # If too many unique or large values, maybe truncate
                    if len(unique_vals) > max_unique_for_cat:
                        unique_vals = unique_vals[:max_unique_for_cat]
                        unique_vals.append("...")
                    col_summary["unique_values_sample"] = unique_vals
                except Exception:
                    pass
        else:
            # Non-numeric likely categorical or text
            col_summary["categorical"] = True
            # If unique count is small, list them
            try:
                unique_vals = list(map(lambda x: x if pd.notna(x) else None, col_data.unique()))
                if len(unique_vals) > max_unique_for_cat:
                    # If too many categories, don't list all
                    unique_vals = unique_vals[:max_unique_for_cat]
                    unique_vals.append("...")
                col_summary["unique_values_sample"] = unique_vals
            except Exception:
                pass
        col_summaries[col] = col_summary
    profile["column_summaries"] = col_summaries
    return profile

def generate_profile_summary_text(profile: dict):
    """
    Generate a human-readable summary text for the dataset profile.
    """
    lines = []
    if "rows" in profile and "columns" in profile:
        lines.append(f"Dataset has {profile['rows']} rows and {profile['columns']} columns.")
    # Summary per column
    for col, summ in profile.get("column_summaries", {}).items():
        parts = [f"{col}:"]
        # If missing data
        if "missing_count" in summ and summ["missing_count"] > 0:
            parts.append(f"missing={summ['missing_count']} ({summ['missing_ratio']*100:.1f}%)")
        # If likely ID
        if summ.get("likely_id"):
            parts.append("likely an ID column (all values unique)")
        # Numeric stats
        if "min" in summ and "max" in summ:
            parts.append(f"min={summ['min']}, max={summ['max']}")
        if "mean" in summ:
            parts.append(f"mean={summ['mean']:.3f}")
        if "std" in summ:
            parts.append(f"std={summ['std']:.3f}")
        # If categorical or considered categorical, list unique count and sample values
        if summ.get("categorical") or summ.get("considered_categorical") or ("unique_count" in summ):
            uc = summ.get("unique_count")
            if uc is not None:
                parts.append(f"unique_values={uc}")
            if "unique_values_sample" in summ:
                sample_vals = summ["unique_values_sample"]
                # Represent list in a compact form
                parts.append(f"sample_values={sample_vals}")
        lines.append(" ".join(parts))
    summary_text = "\n".join(lines)
    return summary_text

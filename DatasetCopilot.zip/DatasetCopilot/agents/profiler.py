from .base import BaseAgent
from core import profiling_utils

class ProfilerAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="profiler")
    def run(self, df):
        """
        Profile the DataFrame and use LLM to summarize the dataset.
        Returns a dict (parsed JSON from LLM).
        """
        # Compute profile stats
        profile = profiling_utils.profile_dataframe(df)
        # Generate a summary text for the dataset profile to feed LLM
        profile_text = profiling_utils.generate_profile_summary_text(profile)
        # Compose user content for LLM
        user_content = (f"Dataset Profile:\n{profile_text}\n"
                        f"Summarize the dataset's key characteristics in JSON format. "
                        f"Include number of rows and columns, lists of numeric and categorical columns, any notable aspects, and a brief summary of the data.")
        result = self._call(user_content)
        return result
